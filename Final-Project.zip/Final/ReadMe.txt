
Steps of execution:

Open google colab

Upload the given code file

for testing single example {

Run the "Installing dependencies and importing libraries" section

Run the "Incontext learning approach" section

Run the "Function for testing the models" section

Run the "UI creation" section

put the review for real time testing 

click on submit

obtain the result

click on flag to save the results in  log file

}

for finetuning base models upload the train csv file,update the path correctly

{

Run the "Installing dependencies and importing libraries" section

Run the "finetuning Ada and Davinci base models section"

Update the job ID and view the obtained model.


view the training results by the job ID 

Use that model for testing

}

for finetuning gpt-3.5-turbo model upload the train csv file,update the path correctly

{

Run the "Installing dependencies and importing libraries" section

Run the "finetuning gpt-3.5-turbo base model" section

Update the job ID and view the obtained model.

view the training results by the job ID 

Use that model for testing

}

For testing upload the test dataset

{

run all the functions

run the testing section and obtain the new CSV file with results in test_results.csv file.

}

